// 참고 부품: 외부 서비스(GitHub·Vercel·Railway·Supabase) 상태·사용량 한 번 읽기 — Node 전용
//
// 이 파일은 학생이 읽고 자기 코드로 다시 만드는 참고 코드입니다. 자동 성취가 아닙니다.
// - 지금 설치된 앱(public/·src/·student/extension.mjs)과 연결되어 있지 않습니다. 앱이 이 파일을 불러오지 않고,
//   같은 폴더의 student-extension.mjs 도 이 파일을 쓰지 않습니다.
// - Node 전용입니다. 브라우저에서 토큰을 입력받는 경로를 만들지 않습니다. document 가 있는 환경에서는
//   createServiceReader 가 바로 거절합니다.
// - 모듈을 불러올 때 네트워크·파일·환경 변수를 건드리지 않습니다. read() 를 명시적으로 부를 때만 요청을 한 번 보내고,
//   재시도하지 않으며, 다음 페이지를 자동으로 읽지 않습니다.
// - 토큰은 read() 인자로만 받습니다. 저장·기록하지 않고 결과에 돌려주지 않으며, Authorization 헤더에만 씁니다.
// - 결과의 ok 는 「이 조회 범위에서 응답이 왔고 정해진 모양으로 읽혔다」는 뜻입니다. 계정 보안, 모든 프로젝트,
//   최종 청구 금액을 확인했다는 뜻이 아닙니다. 금액 합계·종합 보안 점수·안전 판정을 만들지 않습니다.
//
// 결과 모양: { schema, provider, operation, state, observedAt, source:{kind,endpoint,scope,completeness}, data, code? }
// - state: ok | partial | unverifiable | unsupported | not_connected | invalid_input | failed | cancelled | timeout
// - failed 일 때 code: authentication_failed(401) | permission_denied(403) | not_found(404) | rate_limited(429) | request_failed
// - partial 일 때 code 는 아래 PARTIAL_CODES 순서로 가장 앞선 이유 하나입니다. 항목별로 틀린 값은 null 로 남습니다.
// - observedAt 은 이 부품이 결과를 만든 시각(now)입니다. 서비스가 돌려준 시각이 아닙니다.
// - ok/partial 이 아니면 data 는 null 입니다.

export const SAAS_READ_SCHEMA = 'aleph.reference.saas-read.v1';

const MAX_BODY_BYTES = 1024 * 1024;
const MAX_ITEMS = 1000;
const MAX_TOKEN_LENGTH = 4096;
const MAX_RANGE_MS = 366 * 24 * 60 * 60 * 1000;
const GITHUB_API_VERSION = '2026-03-10';
const RAILWAY_STATUS_BODY = JSON.stringify({ query: 'query AlephAccountStatus { me { id } }' });

const PARTIAL_CODES = ['next_page_not_fetched', 'item_limit_exceeded', 'invalid_item', 'item_outside_period', 'graphql_errors'];
const HTTP_CODES = { 401: 'authentication_failed', 403: 'permission_denied', 404: 'not_found', 429: 'rate_limited' };
const VERCEL_CATEGORIES = new Set(['Usage', 'Purchase', 'Tax', 'Credit', 'Adjustment']);
// 미리 허용한 Supabase 프로젝트 상태만 키로 씁니다. 그 밖의 문자열(UNKNOWN 포함)은 unknown 으로 셉니다.
const SUPABASE_STATUSES = new Set([
  'ACTIVE_HEALTHY', 'ACTIVE_UNHEALTHY', 'COMING_UP', 'GOING_DOWN', 'INACTIVE', 'INIT_FAILED', 'REMOVED',
  'RESTARTING', 'UPGRADING', 'PAUSING', 'RESTORING', 'RESTORE_FAILED', 'PAUSE_FAILED', 'RESIZING',
]);

const GITHUB_HANDLE = /^[A-Za-z0-9](?:[A-Za-z0-9]|-(?=[A-Za-z0-9])){0,38}$/;
const VERCEL_TEAM_ID = /^[A-Za-z0-9_-]{1,100}$/;
const SAFE_UNIT = /^[A-Za-z0-9][A-Za-z0-9 _./-]{0,31}$/;
const DECIMAL = /^-?(?:0|[1-9]\d{0,20})(?:\.\d{1,20})?$/;
const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;
const ZONED_ISO = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d{1,9})?)?(?:Z|([+-])(\d{2}):(\d{2}))$/;

// 지원하는 조회마다 고정 주소·범위 종류를 둡니다. endpoint 에는 토큰이나 개인 username/teamId 가 들어가지 않습니다.
const OPERATIONS = {
  github: {
    status: { endpoint: 'https://api.github.com/user', scope: 'user' },
    usage: { endpoint: 'https://api.github.com/users/{username}/settings/billing/usage', scope: 'account' },
  },
  vercel: {
    status: { endpoint: 'https://api.vercel.com/v2/user', scope: 'user' },
    usage: { endpoint: 'https://api.vercel.com/v1/billing/charges', scope: 'team' },
  },
  railway: {
    status: { endpoint: 'https://backboard.railway.com/graphql/v2', scope: 'user' },
  },
  supabase: {
    status: { endpoint: 'https://api.supabase.com/v1/projects', scope: 'visible-projects' },
  },
};
const PROVIDERS = new Set(['github', 'vercel', 'railway', 'supabase']);
const OPERATION_NAMES = new Set(['status', 'usage']);

export function createServiceReader({ fetchImpl = globalThis.fetch, now = () => new Date(), timeoutMs = 10000 } = {}) {
  if (typeof globalThis.document !== 'undefined') throw new Error('service-reader is Node-only; do not collect tokens in a browser');
  if (typeof fetchImpl !== 'function') throw new TypeError('fetchImpl must be a function');
  if (typeof now !== 'function') throw new TypeError('now must be a function');
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new TypeError('timeoutMs must be a positive number');

  async function read(request, options = {}) {
    const known = isPlainObject(request) ? request : {};
    const provider = PROVIDERS.has(known.provider) ? known.provider : null;
    const operation = OPERATION_NAMES.has(known.operation) ? known.operation : null;
    const spec = (provider && operation && OPERATIONS[provider][operation]) || null;
    const out = (state, data = null, code) => buildResult(now, provider, operation, spec, state, data, code);

    if (!isPlainObject(request)) return out('invalid_input', null, 'invalid_request');
    if (!spec) return out('unsupported');
    if (!onlyKeys(request, ['provider','operation','token','scope','period'])) return out('invalid_input', null, 'invalid_request');

    const tokenState = checkToken(request.token);
    if (tokenState) return out(tokenState);

    const plan = planRequest(provider, operation, request);
    if (!plan) return out('invalid_input', null, 'invalid_scope_or_period');

    const signal = options == null ? undefined : options.signal;
    if (signal != null && !isAbortSignal(signal)) return out('invalid_input', null, 'invalid_signal');
    if (signal && signal.aborted) return out('cancelled');

    const fetched = await fetchOnce(fetchImpl, plan, request.token, signal, timeoutMs);
    if (fetched.state) return out(fetched.state, null, fetched.code);
    const parsed = plan.parse(fetched);
    // 허용된 단위 문자열 등으로 자격이 되돌아와도 결과에 옮기지 않는다.
    if (containsCredential(parsed.data, request.token)) return out('unverifiable', null, 'sensitive_response');
    return out(parsed.state, parsed.data ?? null, parsed.code);
  }

  return { read };
}

function buildResult(now, provider, operation, spec, state, data, code) {
  const result = {
    schema: SAAS_READ_SCHEMA,
    provider,
    operation,
    state,
    observedAt: observedAt(now),
    source: {
      kind: 'provider-api',
      endpoint: spec ? spec.endpoint : null,
      scope: spec ? spec.scope : null,
      completeness: state === 'partial' ? 'partial' : 'limited',
    },
    data: state === 'ok' || state === 'partial' ? data : null,
  };
  if (code) result.code = code;
  return result;
}

function observedAt(now) {
  try {
    const value = now();
    return value instanceof Date && Number.isFinite(value.getTime()) ? value.toISOString() : null;
  } catch {
    return null;
  }
}

function checkToken(token) {
  if (token == null) return 'not_connected';
  if (typeof token !== 'string') return 'invalid_input';
  if (token.trim() === '') return 'not_connected';
  if (token.length > MAX_TOKEN_LENGTH) return 'invalid_input';
  // CR/LF·제어 문자·공백·비 ASCII 가 섞인 토큰은 헤더에 넣지 않습니다.
  if (!/^[\x21-\x7e]+$/.test(token)) return 'invalid_input';
  return null;
}

// ---- 요청 계획: 입력을 검증하고 고정 주소·헤더·본문만 만듭니다. 검증에 실패하면 null(네트워크 0회).

function planRequest(provider, operation, request) {
  const scope = request.scope === undefined ? {} : request.scope;
  const period = request.period === undefined ? {} : request.period;
  if (!isPlainObject(scope) || !isPlainObject(period)) return null;
  const scopeKeys = operation === 'status' ? [] : provider === 'github' ? ['username'] : ['teamId'];
  const periodKeys = operation === 'status' ? [] : provider === 'github' ? ['year','month'] : ['from','to'];
  if (!onlyKeys(scope, scopeKeys) || !onlyKeys(period, periodKeys)) return null;
  if (scope.username !== undefined && !(typeof scope.username === 'string' && GITHUB_HANDLE.test(scope.username))) return null;
  if (scope.teamId !== undefined && !(typeof scope.teamId === 'string' && VERCEL_TEAM_ID.test(scope.teamId))) return null;

  const bearer = { Authorization: 'Bearer ' + request.token };
  const github = { ...bearer, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': GITHUB_API_VERSION };

  if (provider === 'github' && operation === 'status') {
    return { method: 'GET', url: 'https://api.github.com/user', headers: github, parse: parseGithubStatus };
  }
  if (provider === 'github' && operation === 'usage') {
    const { year, month } = period;
    if (scope.username === undefined) return null;
    if (!Number.isInteger(year) || year < 2000 || year > 2100) return null;
    if (!Number.isInteger(month) || month < 1 || month > 12) return null;
    const url = 'https://api.github.com/users/' + scope.username + '/settings/billing/usage?'
      + new URLSearchParams({ year: String(year), month: String(month) });
    return { method: 'GET', url, headers: github, parse: res => parseGithubUsage(res, year, month) };
  }
  if (provider === 'vercel' && operation === 'status') {
    return { method: 'GET', url: 'https://api.vercel.com/v2/user', headers: bearer, parse: parseVercelStatus };
  }
  if (provider === 'vercel' && operation === 'usage') {
    if (scope.teamId === undefined) return null;
    const fromMs = parseZonedIso(period.from), toMs = parseZonedIso(period.to);
    if (fromMs === null || toMs === null || !(fromMs < toMs) || toMs - fromMs > MAX_RANGE_MS) return null;
    const url = 'https://api.vercel.com/v1/billing/charges?'
      + new URLSearchParams({ teamId: scope.teamId, from: period.from, to: period.to });
    return { method: 'GET', url, headers: bearer, parse: res => parseVercelCharges(res, fromMs, toMs) };
  }
  if (provider === 'railway' && operation === 'status') {
    return {
      method: 'POST',
      url: 'https://backboard.railway.com/graphql/v2',
      headers: { ...bearer, 'Content-Type': 'application/json' },
      body: RAILWAY_STATUS_BODY,
      parse: parseRailwayStatus,
    };
  }
  if (provider === 'supabase' && operation === 'status') {
    return { method: 'GET', url: 'https://api.supabase.com/v1/projects', headers: bearer, parse: parseSupabaseStatus };
  }
  return null;
}

// ---- 한 번 요청하고 본문을 1MiB 까지만 읽습니다. 시간 제한과 외부 취소는 fetch 와 본문 읽기를 모두 덮습니다.

async function fetchOnce(fetchImpl, plan, token, externalSignal, timeoutMs) {
  const controller = new AbortController();
  let reason = null;
  let rejectAbort;
  const aborted = new Promise((_, reject) => { rejectAbort = reject; });
  aborted.catch(() => {});
  const stop = why => {
    if (reason) return;
    reason = why;
    rejectAbort(new Error('aborted'));
    controller.abort();
  };
  const onExternalAbort = () => stop('cancelled');
  const timer = setTimeout(() => stop('timeout'), timeoutMs);
  if (externalSignal) externalSignal.addEventListener('abort', onExternalAbort, { once: true });
  const race = promise => Promise.race([promise, aborted]);
  let reader = null;
  let finished = false;

  try {
    const init = { method: plan.method, headers: { ...plan.headers }, redirect: 'error', credentials: 'omit', signal: controller.signal };
    if (plan.body !== undefined) init.body = plan.body;
    const response = await race(Promise.resolve().then(() => fetchImpl(plan.url, init)));
    if (!response || typeof response !== 'object' || !Number.isInteger(response.status)) {
      return { state: 'failed', code: 'request_failed' };
    }
    if (response.status < 200 || response.status > 299) {
      discardBody(response);
      return { state: 'failed', code: HTTP_CODES[response.status] || 'request_failed' };
    }
    const declared = Number(headerValue(response, 'content-length'));
    if (Number.isFinite(declared) && declared > MAX_BODY_BYTES) {
      discardBody(response);
      return { state: 'unverifiable', code: 'response_too_large' };
    }

    const chunks = [];
    let total = 0;
    if (response.body != null) {
      if (typeof response.body.getReader !== 'function') return { state: 'unverifiable', code: 'invalid_response' };
      reader = response.body.getReader();
      for (;;) {
        const { done, value } = await race(reader.read());
        if (done) { finished = true; break; }
        if (!(value instanceof Uint8Array)) return { state: 'unverifiable', code: 'invalid_response' };
        total += value.byteLength;
        if (total > MAX_BODY_BYTES) return { state: 'unverifiable', code: 'response_too_large' };
        chunks.push(value);
      }
    }
    const bytes = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
    let text;
    try {
      text = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    } catch {
      return { state: 'unverifiable', code: 'invalid_response' };
    }
    return { text, hasNextPage: hasNextLink(headerValue(response, 'link')) };
  } catch {
    if (reason) return { state: reason };
    return { state: 'failed', code: 'request_failed' };
  } finally {
    clearTimeout(timer);
    if (externalSignal) externalSignal.removeEventListener('abort', onExternalAbort);
    if (reader && !finished) {
      try { reader.cancel().catch(() => {}); } catch { /* 이미 닫힌 본문 */ }
    }
    if (!reason) controller.abort();
  }
}

function discardBody(response) {
  try {
    const body = response.body;
    if (body && typeof body.cancel === 'function') body.cancel().catch(() => {});
  } catch { /* 본문을 읽지 않고 버립니다 */ }
}

function headerValue(response, name) {
  try {
    const value = response.headers && typeof response.headers.get === 'function' ? response.headers.get(name) : null;
    return typeof value === 'string' ? value : null;
  } catch {
    return null;
  }
}

function hasNextLink(link) {
  if (!link) return false;
  return link.split(',').some(part => {
    const rel = /;\s*rel\s*=\s*(?:"([^"]*)"|([^\s;]+))/i.exec(part);
    return Boolean(rel) && (rel[1] ?? rel[2]).toLowerCase().split(/\s+/).includes('next');
  });
}

// ---- 응답 해석: 정해진 필드만 새 객체로 옮깁니다. 응답의 다른 값(이름·이메일·ID·오류 문구)은 옮기지 않습니다.

function parseJson(text) {
  try {
    return { ok: true, value: JSON.parse(text) };
  } catch {
    return { ok: false };
  }
}

function settle(data, reasons, okCode) {
  for (const code of PARTIAL_CODES) {
    if (reasons.has(code)) return { state: 'partial', data, code };
  }
  return { state: 'ok', data, code: okCode };
}

function parseGithubStatus({ text }) {
  const json = parseJson(text);
  const body = json.ok ? json.value : null;
  if (!isPlainObject(body) || !Number.isSafeInteger(body.id) || body.id <= 0 || typeof body.login !== 'string' || body.login === '') {
    return { state: 'unverifiable', code: 'invalid_response' };
  }
  const mfa = typeof body.two_factor_authentication === 'boolean' ? body.two_factor_authentication : null;
  return { state: 'ok', data: { accountResponded: true, mfaEnabled: mfa }, code: mfa === null ? 'mfa_unverified' : undefined };
}

function parseGithubUsage({ text, hasNextPage }, year, month) {
  const json = parseJson(text);
  const body = json.ok ? json.value : null;
  if (!isPlainObject(body) || !Array.isArray(body.usageItems)) return { state: 'unverifiable', code: 'invalid_response' };
  const reasons = new Set();
  if (hasNextPage) reasons.add('next_page_not_fetched');
  if (body.usageItems.length > MAX_ITEMS) reasons.add('item_limit_exceeded');
  const items = body.usageItems.slice(0, MAX_ITEMS).map((raw, index) => {
    const row = isPlainObject(raw) ? raw : {};
    if (!isPlainObject(raw)) reasons.add('invalid_item');
    const date = validIsoDate(row.date);
    const quantity = Number.isFinite(row.quantity) ? row.quantity : null;
    const unit = typeof row.unitType === 'string' && SAFE_UNIT.test(row.unitType) ? row.unitType : null;
    const netAmount = Number.isFinite(row.netAmount) ? String(row.netAmount) : null;
    if (date === null || quantity === null || unit === null || netAmount === null) reasons.add('invalid_item');
    if (date !== null && (Number(date.slice(0, 4)) !== year || Number(date.slice(5, 7)) !== month)) reasons.add('item_outside_period');
    return { index, date, quantity, unit, netAmount };
  });
  // 통화가 응답에 없으므로 USD 로 추정하지 않습니다. 빈 배열은 조회된 행이 0개라는 뜻이지 청구 0원이 아닙니다.
  return settle({ period: { year, month }, currency: null, items, invoiceTotal: null }, reasons, 'currency_unverified');
}

function parseVercelStatus({ text }) {
  const json = parseJson(text);
  const body = json.ok ? json.value : null;
  if (!isPlainObject(body) || !isPlainObject(body.user) || typeof body.user.id !== 'string' || body.user.id === '') {
    return { state: 'unverifiable', code: 'invalid_response' };
  }
  return { state: 'ok', data: { accountResponded: true } };
}

function parseVercelCharges({ text, hasNextPage }, fromMs, toMs) {
  const lines = text.split(/\r?\n/).filter(line => line.trim() !== '');
  const reasons = new Set();
  if (hasNextPage) reasons.add('next_page_not_fetched');
  if (lines.length > MAX_ITEMS) reasons.add('item_limit_exceeded');
  const items = [];
  let parsedRows = 0;
  lines.slice(0, MAX_ITEMS).forEach((line, index) => {
    const json = parseJson(line);
    if (!json.ok || !isPlainObject(json.value)) { reasons.add('invalid_item'); return; }
    parsedRows += 1;
    const row = json.value;
    const billedCost = decimalString(row.BilledCost);
    const currency = typeof row.BillingCurrency === 'string' && /^[A-Z]{3}$/.test(row.BillingCurrency) ? row.BillingCurrency : null;
    const chargeCategory = VERCEL_CATEGORIES.has(row.ChargeCategory) ? row.ChargeCategory : null;
    const fromRow = parseZonedIso(row.ChargePeriodStart);
    const toRow = parseZonedIso(row.ChargePeriodEnd);
    const quantity = decimalString(row.ConsumedQuantity);
    const unit = typeof row.ConsumedUnit === 'string' && SAFE_UNIT.test(row.ConsumedUnit) ? row.ConsumedUnit : null;
    if ([billedCost, currency, chargeCategory, fromRow, toRow, quantity, unit].includes(null)) reasons.add('invalid_item');
    if (fromRow !== null && toRow !== null && fromRow >= toRow) reasons.add('invalid_item');
    if ((fromRow !== null && fromRow < fromMs) || (toRow !== null && toRow > toMs)) reasons.add('item_outside_period');
    items.push({
      index,
      billedCost,
      currency,
      chargeCategory,
      from: fromRow === null ? null : row.ChargePeriodStart,
      to: toRow === null ? null : row.ChargePeriodEnd,
      quantity,
      unit,
    });
  });
  // 행이 있었는데 하나도 JSON 객체로 읽히지 않으면(HTML 등) 응답 형식 자체를 확인할 수 없습니다.
  if (lines.length > 0 && parsedRows === 0) return { state: 'unverifiable', code: 'invalid_response' };
  // 통화가 다르거나 크레딧·음수가 있어도 합치지 않습니다. invoiceTotal 은 항상 null 입니다.
  return settle({ items, invoiceTotal: null }, reasons);
}

function parseRailwayStatus({ text }) {
  const json = parseJson(text);
  const body = json.ok ? json.value : null;
  if (!isPlainObject(body)) return { state: 'unverifiable', code: 'invalid_response' };
  const hasErrors = body.errors !== undefined && body.errors !== null && !(Array.isArray(body.errors) && body.errors.length === 0);
  const me = isPlainObject(body.data) && isPlainObject(body.data.me) ? body.data.me : null;
  if (!me || typeof me.id !== 'string' || me.id === '') {
    return { state: 'unverifiable', code: hasErrors ? 'graphql_errors' : 'invalid_response' };
  }
  return settle({ accountResponded: true }, new Set(hasErrors ? ['graphql_errors'] : []));
}

function parseSupabaseStatus({ text, hasNextPage }) {
  const json = parseJson(text);
  const body = json.ok ? json.value : null;
  if (!Array.isArray(body)) return { state: 'unverifiable', code: 'invalid_response' };
  const reasons = new Set();
  if (hasNextPage) reasons.add('next_page_not_fetched');
  if (body.length > MAX_ITEMS) reasons.add('item_limit_exceeded');
  const statusCounts = {};
  let visibleProjectCount = 0;
  for (const item of body.slice(0, MAX_ITEMS)) {
    if (!isPlainObject(item) || typeof item.id !== 'string' || item.id.trim() === '' || typeof item.status !== 'string') {
      reasons.add('invalid_item');
      continue;
    }
    visibleProjectCount += 1;
    const key = SUPABASE_STATUSES.has(item.status) ? item.status : 'unknown';
    statusCounts[key] = (statusCounts[key] || 0) + 1;
  }
  // 이 토큰으로 보이는 프로젝트만 셉니다. 계정 전체 프로젝트 수나 MFA 로 넓혀 읽지 않습니다.
  return settle({ visibleProjectCount, statusCounts }, reasons);
}

// ---- 값 검증

function isPlainObject(value) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}

function containsCredential(value, token) {
  if (value === null || value === undefined) return false;
  if (typeof value === 'object') return Object.values(value).some(v => containsCredential(v, token));
  return String(value).includes(token);
}

function isAbortSignal(value) {
  return typeof AbortSignal !== 'undefined' && value instanceof AbortSignal;
}

function onlyKeys(object, allowed) {
  return Object.keys(object).every(key => allowed.includes(key));
}

function daysInMonth(year, month) {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

function validIsoDate(value) {
  if (typeof value !== 'string') return null;
  const m = ISO_DATE.exec(value);
  if (!m) return null;
  const year = Number(m[1]), month = Number(m[2]), day = Number(m[3]);
  if (month < 1 || month > 12 || day < 1 || day > daysInMonth(year, month)) return null;
  return value;
}

// 시간대가 붙은 ISO 시각만 받습니다. 달력에 없는 날짜(2월 30일 등)는 넘기지 않고 null 입니다.
function parseZonedIso(value) {
  if (typeof value !== 'string') return null;
  const m = ZONED_ISO.exec(value);
  if (!m) return null;
  const [, y, mo, d, h, mi, s = '0', sign, oh, om] = m;
  const year = Number(y), month = Number(mo), day = Number(d);
  if (month < 1 || month > 12 || day < 1 || day > daysInMonth(year, month)) return null;
  if (Number(h) > 23 || Number(mi) > 59 || Number(s) > 59) return null;
  if (sign && (Number(oh) > 14 || Number(om) > 59)) return null;
  const ms = Date.parse(value);
  return Number.isFinite(ms) ? ms : null;
}

function decimalString(value) {
  if (typeof value === 'string') return DECIMAL.test(value) ? value : null;
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  return null;
}
