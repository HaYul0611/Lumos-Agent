#!/usr/bin/env node
// 독립 Node 참고 도구. 기존 설치 앱·학생 API·자격 저장소에 연결하지 않는다.
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {createServiceReader} from './service-reader.mjs';

const TOKEN_ENV = Object.freeze({
  github: 'ALEPH_REFERENCE_GITHUB_TOKEN',
  vercel: 'ALEPH_REFERENCE_VERCEL_TOKEN',
  railway: 'ALEPH_REFERENCE_RAILWAY_ACCOUNT_TOKEN',
  supabase: 'ALEPH_REFERENCE_SUPABASE_MANAGEMENT_TOKEN',
});
const VALUE_FLAGS = new Set(['--provider','--operation','--username','--team','--year','--month','--from','--to']);
const zonedInstant = v => {
  if (typeof v!=='string' || !/^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d{1,9})?)?(?:Z|[+-]\d{2}:\d{2})$/.test(v) || !Number.isFinite(Date.parse(v))) return false;
  const day=Date.parse(v.slice(0,10)+'T00:00:00Z');
  return Number.isFinite(day) && new Date(day).toISOString().slice(0,10)===v.slice(0,10);
};
const HELP = `SaaS 읽기 전용 참고 도구 (Node.js 22~24)

node examples/pc-saas/read-service.mjs --provider github --operation status

위 명령은 외부 요청을 하지 않습니다. 실제 조회는 대상·작업·범위를 확인한 뒤
--live를 명시할 때만 요청하며, 해당 서비스 전용 환경변수의 토큰만 읽습니다.
토큰을 명령 인자, 브라우저, 저장소, 제출 파일에 넣지 마세요.

--provider github|vercel|railway|supabase
--operation status|usage
GitHub usage: --username <내 계정> --year <연도> --month <월>
Vercel usage: --team <내 팀 ID> --from <시차가 있는 ISO 시각> --to <시차가 있는 ISO 시각>
Railway/Supabase usage는 지원하지 않으며 요청하지 않습니다.
Railway status는 개인 계정 토큰용입니다. 프로젝트·워크스페이스 토큰을 대신 쓰지 마세요.

계정 응답·보이는 프로젝트 수·일부 사용량은 계정 전체 보안이나 최종 청구 확인이 아닙니다.
이 도구는 현재 설치 앱의 화면·학생 API·서명 실행 환경에 연결되지 않습니다.
`;

function argumentsFor(argv) {
  if (!Array.isArray(argv) || argv.some(v => typeof v !== 'string' || v.length > 512 || /[\u0000-\u001f\u007f]/.test(v))) return null;
  const flags = new Map();
  for (let i=0;i<argv.length;i++) {
    const k=argv[i];
    if (flags.has(k)) return null;
    if (k==='--help' || k==='--live') {flags.set(k,true);continue;}
    if (!VALUE_FLAGS.has(k) || i+1>=argv.length || argv[i+1].startsWith('--')) return null;
    flags.set(k,argv[++i]);
  }
  if (flags.has('--help')) return flags.size===1 ? {help:true} : null;
  const provider=flags.get('--provider'),operation=flags.get('--operation');
  if (!Object.hasOwn(TOKEN_ENV,provider) || !['status','usage'].includes(operation)) return null;
  const relevant = operation==='status' ? [] : provider==='github' ? ['--username','--year','--month'] : provider==='vercel' ? ['--team','--from','--to'] : [];
  if ([...flags.keys()].some(k=>!['--provider','--operation','--live',...relevant].includes(k))) return null;
  const request={provider,operation,scope:{},period:{}};
  if (provider==='github' && operation==='usage') {
    const username=flags.get('--username'),year=flags.get('--year'),month=flags.get('--month');
    if (typeof username!=='string' || !/^[A-Za-z0-9](?:[A-Za-z0-9]|-(?=[A-Za-z0-9])){0,38}$/.test(username) || !/^\d{4}$/.test(year??'') || !/^\d{1,2}$/.test(month??'')) return null;
    if (+year<2000 || +year>2100 || +month<1 || +month>12) return null;
    request.scope.username=username; request.period={year:+year,month:+month};
  }
  if (provider==='vercel' && operation==='usage') {
    const teamId=flags.get('--team'),from=flags.get('--from'),to=flags.get('--to');
    if (typeof teamId!=='string' || !/^[A-Za-z0-9_-]{1,100}$/.test(teamId) || !zonedInstant(from) || !zonedInstant(to) || Date.parse(from)>=Date.parse(to) || Date.parse(to)-Date.parse(from)>366*86400000) return null;
    request.scope.teamId=teamId; request.period={from,to};
  }
  return {request,live:flags.has('--live')};
}

export async function runServiceReaderCli(argv, {
  env=process.env,
  writeOut=text=>process.stdout.write(text),
  writeError=text=>process.stderr.write(text),
  createReader=createServiceReader,
}={}) {
  const parsed=argumentsFor(argv);
  if (!parsed) {writeError('인자를 확인하세요. --help에서 사용 방법을 볼 수 있습니다.\n');return 64;}
  if (parsed.help) {writeOut(HELP);return 0;}
  const {request}=parsed;
  if (!parsed.live) {
    writeOut(JSON.stringify({schema:'aleph.reference.saas-cli.v1',provider:request.provider,operation:request.operation,state:'not_requested',code:'EXPLICIT_LIVE_REQUIRED',networkRequests:0})+'\n');
    return 2;
  }
  try {
    // 미지원 작업에는 자격도 읽지 않는다. 일반 CLI·Workbench·학생 앱의 저장 자격은 탐색하지 않는다.
    if (request.operation==='status' || ['github','vercel'].includes(request.provider)) request.token=env[TOKEN_ENV[request.provider]];
    const result=await createReader().read(request);
    writeOut(JSON.stringify({...result,reference:{integrationStage:'standalone_reference_only',localOnly:true,billingNotice:request.operation==='usage'?'일부 공급자 사용량입니다. 조회 시각과 집계 시각은 다를 수 있으며 실시간 잔액·최종 청구액·결제 한도 확인이 아닙니다.':null}})+'\n');
    return ['ok','partial'].includes(result?.state) ? 0 : 2;
  } catch {writeError('요청 결과를 확인하지 못했습니다. 원문 오류와 자격 정보는 출력하지 않습니다.\n');return 70;}
}

if (process.argv[1] && fileURLToPath(import.meta.url)===resolve(process.argv[1])) {
  process.exitCode=await runServiceReaderCli(process.argv.slice(2));
}
