# SaaS 조회를 준비하는 독립 Node 참고 도구

이 도구는 개인 PC에서 서비스의 응답을 읽는 방법을 보여 주는 선택 자료입니다. 필수 과제나 추가 제출 조건이 아닙니다. 토큰을 발급하거나 외부 서비스를 가입할 필요 없이 기존 제작 과제를 계속할 수 있습니다. 결과는 본인 PC 터미널에서만 읽으며 교강사 서버·DB·채널로 전송하지 않습니다.

현재 설치 앱의 화면, `studentApi`, 승인된 실행 환경, 시험0반 `.18/R6` 패키지에는 연결하지 않았습니다. 기존 `student/extension.mjs`나 제공 파일을 이 코드로 덮어쓰지 않습니다. 학생 화면에서 직접 외부 API를 부르거나 새 주소로 우회하는 예제도 아닙니다. 설치 앱 연결은 별도의 제공 코드·권한·패키지 검증이 필요한 후속 작업입니다.

## 현재 구현 범위

| 서비스 | `status`에서 확인하는 것 | `usage`에서 확인하는 것 |
|---|---|---|
| GitHub | 개인 계정 조회 응답, 응답에 명시된 경우에만 2FA 여부 | 지정한 개인 계정·연월의 사용량 행. 응답에 통화가 없으므로 통화 미확인. 최종 월 청구액은 계산하지 않음 |
| Vercel | 인증된 사용자 조회 응답 | 지정한 팀·기간의 FOCUS 청구 행. 행별 통화·기간·크레딧을 유지하며 합계하지 않음 |
| Railway | 개인 계정 토큰으로 고정 GraphQL `me` 조회 | 지원 없음. 비용 필드·청구 범위를 확인하지 않았으므로 요청하지 않음 |
| Supabase | Management API에서 보이는 프로젝트 수와 상태 집계 | 지원 없음. 확인하지 않은 비용 주소를 만들거나 0원으로 표시하지 않음 |

조회 성공은 표의 범위에만 해당합니다. 모든 프로젝트를 봤거나 MFA·취약점·배포 보호·전체 계정 보안을 확인했다는 뜻이 아닙니다. 프로젝트가 정상으로 보이더라도 보안상 안전하다고 판단하지 않습니다. 공급자 집계가 늦을 수 있으므로 사용량 조회 시각과 실제 사용 발생 시각, 최종 청구 시점도 구분합니다.

## 외부 요청 없이 먼저 읽어 보기

Node.js 22~24가 있는 앱 폴더(`package.json`과 `examples`가 함께 있는 곳)에서 실행합니다. 저장소 전체를 받았다면 앱 폴더는 `education/on-client`입니다. 현재 배포된 시작 틀에는 이 후속 파일이 아직 포함되지 않을 수 있으므로 존재 여부를 먼저 확인합니다.

```powershell
node examples/pc-saas/read-service.mjs --help
node examples/pc-saas/read-service.mjs --provider github --operation status
```

두 명령 모두 외부 요청을 하지 않습니다. 두 번째 명령은 `not_requested`, `EXPLICIT_LIVE_REQUIRED`, `networkRequests: 0`을 반환하고 종료 코드 2로 끝납니다. 실패한 계정 조회가 아니라 실제 조회를 요청하지 않았다는 뜻입니다.

## 실제 조회는 별도로 준비합니다

원하는 서비스·작업·계정 또는 팀·기간과 토큰의 실제 허용 범위를 먼저 확인합니다. 이 준비는 운영자의 시험0반 확인을 대신하지 않습니다. 기존 Workbench나 학생 앱의 자격 파일을 찾아 복사하지 않습니다.

| 서비스 | 이 도구가 읽는 전용 환경변수 | 권한을 확인할 범위 |
|---|---|---|
| GitHub | `ALEPH_REFERENCE_GITHUB_TOKEN` | 개인 사용량은 공식 문서의 Plan 읽기 권한 및 해당 청구 체계 적용 여부 확인. 개인 청구는 조직·기업 청구와 다름 |
| Vercel | `ALEPH_REFERENCE_VERCEL_TOKEN` | 사용자가 볼 수 있는 팀과 Billing 조회 역할 확인. Marketplace 청구 데이터 쓰기 API는 사용하지 않음 |
| Railway | `ALEPH_REFERENCE_RAILWAY_ACCOUNT_TOKEN` | 개인 계정 조회용 토큰. 프로젝트·워크스페이스 토큰을 개인 계정 토큰 대신 쓰지 않음 |
| Supabase | `ALEPH_REFERENCE_SUPABASE_MANAGEMENT_TOKEN` | 프로젝트 읽기를 허용한 범위 제한 Management PAT 또는 OAuth. Data API의 publishable/anon/service-role/secret 키로 대신하지 않음 |

토큰 값은 명령 인자나 PowerShell 명령 기록에 직접 적지 않습니다. 승인된 비밀 관리 도구나 호출 프로세스가 현재 프로세스의 전용 환경변수로 전달하도록 준비하고, 쓰기·관리 권한을 추가로 요구하지 않습니다. 이 도구가 읽기 요청만 보낸다는 사실과 토큰 자체에 읽기 권한만 있다는 사실은 서로 다릅니다. 지원되는 최소 범위·만료를 확인하고 더 이상 쓰지 않는 자격은 서비스의 정상 관리 절차로 정리합니다. 이 참고 도구는 자격을 발급·저장·회수하지 않습니다.

원하는 조회에 맞는 좁은 권한을 준비할 수 없다면 미연결로 두고 다른 제작 작업을 계속합니다. 이 예제를 실행하려고 광범위한 관리 토큰을 새로 만들 필요는 없습니다.

아래는 자격과 대상을 확인한 뒤 본인이 선택하는 명령 형식입니다. 토큰 값은 포함하지 않습니다.

```powershell
node examples/pc-saas/read-service.mjs --provider github --operation status --live
node examples/pc-saas/read-service.mjs --provider github --operation usage --username "내-GitHub-계정" --year 2026 --month 10 --live
node examples/pc-saas/read-service.mjs --provider vercel --operation usage --team "내-팀-ID" --from "2026-10-01T00:00:00+09:00" --to "2026-10-24T00:00:00+09:00" --live
```

계정과 팀 자리에는 본인이 확인한 실제 식별자를 넣습니다. 연도·월·기간도 원하는 조회 범위로 바꿉니다. `--live` 없이 먼저 형식을 확인할 수 있습니다. 토큰이 없으면 `not_connected`이며 다른 자격이나 모델을 찾아 대신 쓰지 않습니다. 실제 조회는 본인의 PC에서 해당 서비스로 인증 요청을 보냅니다.

## 결과를 해석하는 방법

- `ok`는 해당 응답의 최소 형식을 읽었다는 뜻입니다. `partial`은 일부 결과나 범위 제한이 있다는 뜻이며 둘 다 계정 전체 정상 판정이 아닙니다.
- 401·403·404·429, 취소·시간 초과·확인 불가·지원 없음은 구분합니다. 권한이 없으면 권한을 임의로 늘리거나 다른 토큰으로 재시도하지 않습니다.
- GitHub의 통화 미확인, Vercel의 서로 다른 통화와 음수 크레딧을 임의로 원화 환산하거나 더하지 않습니다. 반환되는 `invoiceTotal: null`은 최종 청구액 미확인입니다. 빈 사용량 행도 월 청구액 0원을 뜻하지 않습니다.
- 반환하는 출처와 조회 시각은 PC가 그 요청을 처리한 근거입니다. 공급자 원문 전체, 토큰, 이메일, 계정·프로젝트 이름이나 식별자는 출력하지 않습니다. 결과를 과제 제출이나 화면 캡처에 쓰려면 남은 민감 정보도 본인이 확인합니다.
- 고정된 공급자 주소에 한 번만 요청하고 리디렉션·자동 재시도·추가 페이지 조회를 하지 않습니다. 일부 페이지만 받은 결과를 전체 자료처럼 쓰지 않습니다.

## 공식 근거와 검증 범위

2026-10-24에 다음 공식 원문을 조회해 계약을 확인했습니다. 인증된 실제 사용자 API 응답을 받았다는 뜻은 아닙니다.

- [GitHub Billing usage](https://docs.github.com/en/rest/billing/usage?apiVersion=2026-03-10)
- [Vercel 사용자 조회](https://vercel.com/docs/rest-api/user/get-the-user), [FOCUS 청구 행 조회](https://vercel.com/docs/rest-api/billing/list-focus-billing-charges)
- [Railway Public API](https://docs.railway.com/integrations/api), [API Cookbook](https://docs.railway.com/integrations/api/api-cookbook)
- [Supabase Management API](https://supabase.com/docs/reference/api/introduction), [공개 변경 기록](https://supabase.com/changelog)

이 후속은 fake fetch 합성 시험으로 요청·해석·비밀값 비노출·중단 경계를 검증합니다. 실제 서비스 연결, 비용 일치, 학생 PC 수용, 현재 설치 앱 화면 반영과 일반 배포는 각각 별도 확인이 필요합니다. 관련 전체 가이드는 [PC_SAAS_REFERENCE.md](../../docs/PC_SAAS_REFERENCE.md), 기존 화면 참고 코드는 [README.md](README.md)에 있습니다.
